// تایپ‌ها، ثابت‌ها و توابع کمکی فروشگاه یونی‌شاپ شیراز

export type ProductType = "BOOK" | "PAMPHLET";
export type ProductCondition = "NEW" | "LIKE_NEW" | "USED";

export interface Product {
  id: string;
  title: string;
  author: string;
  type: ProductType;
  category: string;
  course: string | null;
  university: string | null;
  price: number;
  condition: ProductCondition;
  description: string | null;
  sellerName: string;
  phone: string;
  status: string;
  featured: boolean;
  views: number;
  createdAt: string;
}

// ---------- دسته‌بندی‌ها ----------
export interface CategoryDef {
  slug: string;
  label: string;
  gradient: string; // کلاس گرادیان جلد کتاب
  soft: string; // رنگ ملایم پس‌زمینه آیکون
  text: string; // رنگ آیکون
}

export const CATEGORIES: CategoryDef[] = [
  {
    slug: "مهندسی",
    label: "مهندسی",
    gradient: "from-slate-700 to-teal-700",
    soft: "bg-teal-50",
    text: "text-teal-700",
  },
  {
    slug: "کامپیوتر",
    label: "کامپیوتر و برنامه‌نویسی",
    gradient: "from-teal-600 to-emerald-700",
    soft: "bg-emerald-50",
    text: "text-emerald-700",
  },
  {
    slug: "پزشکی و پیراپزشکی",
    label: "پزشکی و پیراپزشکی",
    gradient: "from-rose-500 to-rose-800",
    soft: "bg-rose-50",
    text: "text-rose-700",
  },
  {
    slug: "علوم پایه",
    label: "علوم پایه",
    gradient: "from-violet-600 to-purple-800",
    soft: "bg-violet-50",
    text: "text-violet-700",
  },
  {
    slug: "ادبیات و انسانی",
    label: "ادبیات و علوم انسانی",
    gradient: "from-amber-500 to-orange-700",
    soft: "bg-amber-50",
    text: "text-amber-700",
  },
  {
    slug: "زبان‌های خارجی",
    label: "زبان‌های خارجی",
    gradient: "from-cyan-600 to-cyan-800",
    soft: "bg-cyan-50",
    text: "text-cyan-700",
  },
  {
    slug: "کنکور و ارشد",
    label: "کنکور و ارشد",
    gradient: "from-orange-500 to-red-700",
    soft: "bg-orange-50",
    text: "text-orange-700",
  },
  {
    slug: "جزوه‌ها",
    label: "جزوه‌های اساتید",
    gradient: "from-emerald-500 to-teal-700",
    soft: "bg-lime-50",
    text: "text-lime-700",
  },
];

export function categoryDef(category: string): CategoryDef {
  return (
    CATEGORIES.find((c) => c.slug === category) ?? {
      slug: category,
      label: category,
      gradient: "from-teal-600 to-teal-800",
      soft: "bg-teal-50",
      text: "text-teal-700",
    }
  );
}

// ---------- برچسب‌ها ----------
export const TYPE_LABEL: Record<ProductType, string> = {
  BOOK: "کتاب",
  PAMPHLET: "جزوه",
};

export const CONDITION_LABEL: Record<ProductCondition, string> = {
  NEW: "نو",
  LIKE_NEW: "در حد نو",
  USED: "کارکرده",
};

// ---------- قالب‌بندی ----------
const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function toPersianDigits(input: string | number): string {
  return String(input).replace(/\d/g, (d) => PERSIAN_DIGITS[Number(d)]);
}

export function formatPrice(price: number): string {
  const grouped = Math.round(price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "،");
  return toPersianDigits(grouped);
}

export function timeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const minutes = Math.max(0, Math.floor(diffMs / 60000));
  if (minutes < 1) return "همین حالا";
  if (minutes < 60) return `${toPersianDigits(minutes)} دقیقه پیش`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${toPersianDigits(hours)} ساعت پیش`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${toPersianDigits(days)} روز پیش`;
  const months = Math.floor(days / 30);
  return `${toPersianDigits(months)} ماه پیش`;
}
