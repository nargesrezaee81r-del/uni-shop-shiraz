"use client";

import { useState } from "react";
import { MapPin, Menu, Plus, Store } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Logo } from "./logo";
import { cn } from "@/lib/utils";

export type ViewKind = "home" | "shop";

interface HeaderProps {
  view: ViewKind;
  onNavigateHome: () => void;
  onNavigateShop: () => void;
  onScrollTo: (id: string) => void;
  onOpenSell: () => void;
}

const NAV_ITEMS: { label: string; action: "home" | "shop" | "scroll"; target?: string }[] = [
  { label: "خانه", action: "home" },
  { label: "فروشگاه", action: "shop" },
  { label: "دسته‌بندی‌ها", action: "scroll", target: "categories" },
  { label: "جدیدترین‌ها", action: "scroll", target: "newest" },
  { label: "درباره ما", action: "scroll", target: "about" },
];

export function Header({
  view,
  onNavigateHome,
  onNavigateShop,
  onScrollTo,
  onOpenSell,
}: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (item: (typeof NAV_ITEMS)[number]) => {
    setMobileOpen(false);
    if (item.action === "home") onNavigateHome();
    else if (item.action === "shop") onNavigateShop();
    else if (item.target) onScrollTo(item.target);
  };

  const isActive = (item: (typeof NAV_ITEMS)[number]) =>
    (item.action === "home" && view === "home" && !item.target) ||
    (item.action === "shop" && view === "shop");

  return (
    <header className="sticky top-0 z-40 w-full">
      {/* نوار بالایی */}
      <div className="bg-teal-900 text-teal-50">
        <div className="mx-auto flex h-8 max-w-6xl items-center justify-between px-4 text-[11px]">
          <p className="flex items-center gap-1.5">
            <MapPin className="h-3 w-3 text-amber-400" />
            شیراز، دانشگاه‌های شهر شیراز
          </p>
          <p className="hidden sm:block">خرید و فروش کتاب و جزوه بین دانشجویان — بدون واسطه</p>
        </div>
      </div>

      {/* هدر اصلی */}
      <div className="border-b bg-background/85 backdrop-blur-md shadow-sm">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
          <Logo onClick={onNavigateHome} />

          {/* منوی دسکتاپ */}
          <nav className="hidden md:flex items-center gap-1" aria-label="منوی اصلی">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.label}
                type="button"
                onClick={() => handleNav(item)}
                className={cn(
                  "rounded-lg px-3.5 py-2 text-sm font-medium transition-colors hover:bg-teal-50 hover:text-teal-800",
                  isActive(item) ? "text-teal-800 bg-teal-50 font-bold" : "text-muted-foreground"
                )}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button
              onClick={onOpenSell}
              className="bg-amber-500 text-white hover:bg-amber-600 shadow-md shadow-amber-500/25 hidden sm:inline-flex"
            >
              <Plus className="h-4 w-4" />
              ثبت آگهی فروش
            </Button>

            {/* منوی موبایل */}
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="md:hidden" aria-label="باز کردن منو">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 p-0">
                <SheetHeader className="border-b p-4 text-right">
                  <SheetTitle>
                    <Logo size="sm" />
                  </SheetTitle>
                  <SheetDescription className="sr-only">منوی ناوبری موبایل یونی‌شاپ شیراز</SheetDescription>
                </SheetHeader>
                <nav className="flex flex-col gap-1 p-3" aria-label="منوی موبایل">
                  {NAV_ITEMS.map((item) => (
                    <button
                      key={item.label}
                      type="button"
                      onClick={() => handleNav(item)}
                      className={cn(
                        "rounded-lg px-3 py-2.5 text-right text-sm font-medium transition-colors hover:bg-teal-50",
                        isActive(item) ? "bg-teal-50 text-teal-800 font-bold" : "text-foreground"
                      )}
                    >
                      {item.label}
                    </button>
                  ))}
                  <div className="my-2 h-px bg-border" />
                  <Button
                    onClick={() => {
                      setMobileOpen(false);
                      onOpenSell();
                    }}
                    className="w-full bg-amber-500 text-white hover:bg-amber-600"
                  >
                    <Plus className="h-4 w-4" />
                    ثبت کتاب یا جزوه برای فروش
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleNav(NAV_ITEMS[1])}
                    className="w-full"
                  >
                    <Store className="h-4 w-4" />
                    ورود به فروشگاه
                  </Button>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
