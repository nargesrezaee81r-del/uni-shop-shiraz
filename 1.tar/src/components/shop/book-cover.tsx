"use client";

import { BookOpen, ScrollText, Landmark } from "lucide-react";
import { categoryDef, TYPE_LABEL, toPersianDigits, type ProductType } from "@/lib/shop";
import { cn } from "@/lib/utils";

interface BookCoverProps {
  title: string;
  author: string;
  category: string;
  type: ProductType;
  className?: string;
  compact?: boolean;
}

/**
 * جلد کتاب یا جزوه به صورت گرافیکی (بدون نیاز به عکس) —
 * با گرادیان متناسب با دسته‌بندی، عطف کتاب و حاشیه‌های تزئینی
 */
export function BookCover({
  title,
  author,
  category,
  type,
  className,
  compact = false,
}: BookCoverProps) {
  const def = categoryDef(category);
  const isPamphlet = type === "PAMPHLET";

  return (
    <div
      className={cn(
        "relative aspect-[3/4] w-full overflow-hidden rounded-lg rounded-l-sm bg-gradient-to-br shadow-md select-none",
        def.gradient,
        className
      )}
      aria-hidden="true"
    >
      {/* عطف کتاب — سمت راست در چیدمان راست‌به‌چپ */}
      <div className="absolute inset-y-0 right-0 w-[7%] bg-black/25" />
      <div className="absolute inset-y-0 right-[7%] w-px bg-white/30" />

      {/* حاشیه تزئینی ایرانی */}
      <div className="absolute inset-[6%] rounded-sm border border-white/25 pointer-events-none" />
      <div className="absolute inset-[9%] rounded-sm border border-white/10 pointer-events-none" />

      {/* دایره‌های تزئینی */}
      <div className="absolute -top-8 -left-8 h-28 w-28 rounded-full bg-white/10" />
      <div className="absolute -bottom-10 -left-10 h-32 w-32 rounded-full bg-black/10" />
      <div className="absolute top-3 left-3 h-10 w-10 rounded-full bg-amber-300/30 blur-[2px]" />

      {/* محتوا */}
      <div
        className={cn(
          "absolute inset-0 flex flex-col justify-between text-white",
          compact ? "p-3 pr-[14%]" : "p-4 pr-[16%] sm:p-5 sm:pr-[16%]"
        )}
      >
        <div className="flex items-center gap-1.5">
          <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2 py-0.5 text-[10px] font-medium backdrop-blur-sm">
            {isPamphlet ? (
              <ScrollText className="h-3 w-3" />
            ) : (
              <BookOpen className="h-3 w-3" />
            )}
            {TYPE_LABEL[type]}
          </span>
        </div>

        <div>
          <h3
            className={cn(
              "font-bold leading-snug drop-shadow-sm",
              compact ? "text-xs line-clamp-3" : "text-sm line-clamp-4 sm:text-base"
            )}
          >
            {title}
          </h3>
          <p
            className={cn(
              "mt-1 text-white/80 line-clamp-1",
              compact ? "text-[10px]" : "text-xs"
            )}
          >
            {author}
          </p>
        </div>

        <div className="flex items-center gap-1 text-white/70">
          <Landmark className="h-3 w-3 shrink-0" />
          <span className={cn("line-clamp-1", compact ? "text-[9px]" : "text-[10px]")}>
            {toPersianDigits(category)}
          </span>
        </div>
      </div>
    </div>
  );
}
