"use client";

import { Heart, Mail, MapPin, Phone } from "lucide-react";
import { Logo } from "./logo";
import type { ViewKind } from "./header";

interface FooterProps {
  onNavigate: (view: ViewKind, sectionId?: string) => void;
  onOpenSell: () => void;
}

export function Footer({ onNavigate, onOpenSell }: FooterProps) {
  const links: { label: string; view: ViewKind; sectionId?: string }[] = [
    { label: "خانه", view: "home" },
    { label: "فروشگاه و محصولات", view: "shop" },
    { label: "دسته‌بندی‌ها", view: "home", sectionId: "categories" },
    { label: "جدیدترین کتاب‌ها", view: "home", sectionId: "newest" },
    { label: "پرفروش‌ترین‌ها", view: "home", sectionId: "featured" },
    { label: "درباره ما", view: "home", sectionId: "about" },
  ];

  return (
    <footer className="mt-auto border-t bg-teal-950 text-teal-50">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 md:grid-cols-3">
        {/* درباره */}
        <div>
          <Logo size="md" variant="footer" onClick={() => onNavigate("home")} />
          <p className="mt-4 max-w-sm text-sm leading-7 text-teal-100/80">
            یونی‌شاپ شیراز؛ بازار آنلاین کتاب و جزوه دانشگاهی برای دانشجویان دانشگاه‌های
            شیراز. خرید و فروش مستقیم، بدون واسطه و بدون کمیسیون.
          </p>
        </div>

        {/* دسترسی سریع */}
        <nav aria-label="دسترسی سریع">
          <h3 className="text-sm font-black text-amber-400">دسترسی سریع</h3>
          <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2.5">
            {links.map((l) => (
              <li key={l.label}>
                <button
                  type="button"
                  onClick={() => onNavigate(l.view, l.sectionId)}
                  className="text-sm text-teal-100/80 transition-colors hover:text-amber-300"
                >
                  {l.label}
                </button>
              </li>
            ))}
            <li>
              <button
                type="button"
                onClick={onOpenSell}
                className="text-sm font-bold text-amber-300 transition-colors hover:text-amber-200"
              >
                ثبت آگهی فروش
              </button>
            </li>
          </ul>
        </nav>

        {/* تماس */}
        <div>
          <h3 className="text-sm font-black text-amber-400">تماس با ما</h3>
          <ul className="mt-4 space-y-3 text-sm text-teal-100/80">
            <li className="flex items-center gap-2">
              <MapPin className="h-4 w-4 shrink-0 text-teal-400" />
              شیراز، خیابان دانشگاه، جنب دانشگاه شیراز
            </li>
            <li className="flex items-center gap-2">
              <Phone className="h-4 w-4 shrink-0 text-teal-400" />
              <span dir="ltr">071-31234567</span>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="h-4 w-4 shrink-0 text-teal-400" />
              <span dir="ltr">info@unishopshiraz.ir</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-teal-900">
        <p className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-1.5 px-4 py-4 text-center text-xs text-teal-100/70">
          © ۱۴۰۴ یونی‌شاپ شیراز — همه حقوق محفوظ است. ساخته‌شده با
          <Heart className="h-3.5 w-3.5 fill-rose-500 text-rose-500" />
          برای دانشجویان شیراز
        </p>
      </div>
    </footer>
  );
}
