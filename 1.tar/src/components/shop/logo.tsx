"use client";

import { GraduationCap } from "lucide-react";
import { cn } from "@/lib/utils";

/** لوگوی یونی‌شاپ شیراز: کتاب باز + کلاه فارغ‌التحصیلی */
export function Logo({
  size = "md",
  variant = "default",
  onClick,
}: {
  size?: "sm" | "md" | "lg";
  variant?: "default" | "footer";
  onClick?: () => void;
}) {
  const box =
    size === "lg" ? "h-14 w-14 rounded-2xl" : size === "sm" ? "h-9 w-9 rounded-lg" : "h-11 w-11 rounded-xl";
  const title = size === "lg" ? "text-2xl" : size === "sm" ? "text-base" : "text-lg";

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-2.5 text-right focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-lg"
      aria-label="یونی‌شاپ شیراز — بازگشت به خانه"
    >
      <span
        className={cn(
          "relative grid place-items-center bg-gradient-to-br from-teal-600 via-teal-700 to-emerald-800 shadow-md shrink-0",
          box
        )}
      >
        {/* کتاب باز */}
        <svg viewBox="0 0 24 24" fill="none" className="absolute h-7 w-7 text-white/95">
          <path
            d="M12 6.5C10 5 7 4.5 4 4.5v13c3 0 6 .5 8 2 2-1.5 5-2 8-2v-13c-3 0-6 .5-8 2Z"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
          <path d="M12 6.5v13" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
        {/* کلاه فارغ‌التحصیلی طلایی */}
        <GraduationCap className="absolute -top-1.5 -left-1.5 h-5 w-5 rounded-full bg-amber-400 p-0.5 text-teal-900 shadow" />
      </span>

      <span className="flex flex-col leading-tight">
        <span dir="ltr" className={cn("font-black tracking-tight", title, variant === "footer" ? "text-white" : "text-foreground")}>
          Uni<span className={variant === "footer" ? "text-teal-300" : "text-teal-700"}>Shop</span>{" "}
          <span className="text-amber-400">Shiraz</span>
        </span>
        <span className={cn("text-[10px] font-medium", variant === "footer" ? "text-teal-300/80" : "text-muted-foreground")}>
          بازار کتاب و جزوه دانشگاهیان شیراز
        </span>
      </span>
    </button>
  );
}
