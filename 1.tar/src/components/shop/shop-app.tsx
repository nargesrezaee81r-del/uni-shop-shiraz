"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Header, type ViewKind } from "./header";
import { Hero } from "./hero";
import { CategoryGrid } from "./category-grid";
import { ProductSection } from "./product-section";
import { AboutSection } from "./about-section";
import { Footer } from "./footer";
import { ShopView } from "./shop-view";
import { ProductDialog } from "./product-dialog";
import { SellDialog } from "./sell-dialog";
import type { Product } from "@/lib/shop";

interface HomeState {
  query: string;
  category: string;
  type: string;
  resetKey: number;
}

export function ShopApp() {
  const [view, setView] = useState<ViewKind>("home");
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Product | null>(null);
  const [sellOpen, setSellOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [shopState, setShopState] = useState<HomeState>({
    query: "",
    category: "all",
    type: "all",
    resetKey: 0,
  });

  // دریافت همه محصولات برای صفحه خانه
  const loadProducts = useCallback(async () => {
    try {
      const res = await fetch("/api/products");
      const data = await res.json();
      if (res.ok) setProducts(data.products);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  const refreshAll = useCallback(() => {
    loadProducts();
    setRefreshKey((k) => k + 1);
  }, [loadProducts]);

  // ---------- ناوبری ----------
  const scrollTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  const goToHome = useCallback(() => {
    setView("home");
    scrollTop();
  }, []);

  const goToShop = useCallback(() => {
    setView("shop");
    scrollTop();
  }, []);

  const scrollToSection = useCallback(
    (id: string) => {
      const scroll = () =>
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
      if (view !== "home") {
        setView("home");
        setTimeout(scroll, 120);
      } else {
        scroll();
      }
    },
    [view]
  );

  const navigateFromFooter = useCallback(
    (target: ViewKind, sectionId?: string) => {
      if (sectionId) scrollToSection(sectionId);
      else if (target === "shop") goToShop();
      else goToHome();
    },
    [goToHome, goToShop, scrollToSection]
  );

  // ---------- جستجو و دسته‌بندی ----------
  const handleSearch = useCallback((query: string, type: string) => {
    setShopState((s) => ({
      query,
      category: "all",
      type,
      resetKey: s.resetKey + 1,
    }));
    setView("shop");
    scrollTop();
  }, []);

  const handleSelectCategory = useCallback((category: string) => {
    setShopState((s) => ({
      query: "",
      category,
      type: "all",
      resetKey: s.resetKey + 1,
    }));
    setView("shop");
    scrollTop();
  }, []);

  // ---------- داده‌های صفحه خانه ----------
  const newest = useMemo(
    () =>
      [...products]
        .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
        .slice(0, 8),
    [products]
  );

  const featured = useMemo(
    () =>
      [...products]
        .filter((p) => p.featured)
        .sort((a, b) => b.views - a.views)
        .slice(0, 8),
    [products]
  );

  const heroSamples = useMemo(() => featured.slice(0, 3), [featured]);

  return (
    <div className="flex min-h-screen flex-col">
      <Header
        view={view}
        onNavigateHome={goToHome}
        onNavigateShop={goToShop}
        onScrollTo={scrollToSection}
        onOpenSell={() => setSellOpen(true)}
      />

      <main className="flex-1">
        {view === "home" ? (
          <>
            <Hero
              onSearch={handleSearch}
              onOpenSell={() => setSellOpen(true)}
              onGoShop={goToShop}
              totalProducts={products.length}
              sampleProducts={heroSamples}
            />
            <CategoryGrid products={products} onSelectCategory={handleSelectCategory} />
            <div className="border-y bg-white/60">
              <ProductSection
                id="newest"
                kicker="تازه رسیده‌ها"
                title="کتاب‌ها و جزوه‌های جدید"
                description="آخرین آگهی‌هایی که دانشجویان در یونی‌شاپ ثبت کرده‌اند؛ تازه و آماده معامله."
                products={newest}
                onViewAll={goToShop}
                onOpenProduct={setSelected}
              />
            </div>
            <ProductSection
              id="featured"
              kicker="انتخاب هفته"
              title="محصولات پرفروش و پیشنهادی"
              description="پرطرفدارترین کتاب‌ها و جزوه‌ها بر اساس بازدید و استقبال دانشجویان شیراز."
              products={featured}
              onViewAll={goToShop}
              onOpenProduct={setSelected}
              emptyText="هنوز محصولی به عنوان پرفروش علامت نخورده است."
            />
            <AboutSection onOpenSell={() => setSellOpen(true)} />
          </>
        ) : (
          <ShopView
            key={shopState.resetKey}
            initialQuery={shopState.query}
            initialCategory={shopState.category}
            initialType={shopState.type}
            refreshKey={refreshKey}
            onOpenProduct={setSelected}
          />
        )}
      </main>

      <Footer onNavigate={navigateFromFooter} onOpenSell={() => setSellOpen(true)} />

      <ProductDialog product={selected} onClose={() => setSelected(null)} />
      <SellDialog
        open={sellOpen}
        onOpenChange={setSellOpen}
        onSuccess={() => {
          refreshAll();
          goToShop();
        }}
      />
    </div>
  );
}
