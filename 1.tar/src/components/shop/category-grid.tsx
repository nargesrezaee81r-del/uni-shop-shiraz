"use client";

import { DraftingCompass, Laptop, Stethoscope, FlaskConical, BookOpen, Languages, GraduationCap, NotebookPen, ArrowLeft } from "lucide-react";
import { CATEGORIES, toPersianDigits, type Product } from "@/lib/shop";
import { SectionHeading } from "./section-heading";

const CATEGORY_ICONS = [DraftingCompass, Laptop, Stethoscope, FlaskConical, BookOpen, Languages, GraduationCap, NotebookPen];

interface CategoryGridProps {
  products: Product[];
  onSelectCategory: (category: string) => void;
}

export function CategoryGrid({ products, onSelectCategory }: CategoryGridProps) {
  const counts = CATEGORIES.map(
    (c) => products.filter((p) => p.category === c.slug).length
  );

  return (
    <section id="categories" className="mx-auto max-w-6xl scroll-mt-32 px-4 py-12 md:py-16">
      <SectionHeading
        kicker="دسته‌بندی محصولات"
        title="دنبال چه چیزی می‌گردی؟"
        description="کتاب‌ها و جزوه‌ها را بر اساس رشته و نیاز دانشگاهی خود مرور کن."
      />

      <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 sm:gap-4">
        {CATEGORIES.map((cat, i) => {
          const Icon = CATEGORY_ICONS[i];
          return (
            <button
              key={cat.slug}
              type="button"
              onClick={() => onSelectCategory(cat.slug)}
              className="group relative overflow-hidden rounded-2xl border bg-card p-4 text-right shadow-sm transition-all duration-200 hover:-translate-y-1 hover:border-teal-300 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:p-5"
            >
              <div
                className={`absolute -left-6 -top-6 h-16 w-16 rounded-full ${cat.soft} transition-transform duration-300 group-hover:scale-150`}
                aria-hidden="true"
              />
              <div className="relative">
                <span className={`inline-grid h-11 w-11 place-items-center rounded-xl ${cat.soft}`}>
                  <Icon className={`h-5 w-5 ${cat.text}`} />
                </span>
                <h3 className="mt-3 text-sm font-bold text-foreground sm:text-base">{cat.label}</h3>
                <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                  {toPersianDigits(counts[i])} آگهی فعال
                  <ArrowLeft className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-100" />
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
