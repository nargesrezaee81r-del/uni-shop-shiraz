"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Search, PackageSearch, RotateCcw, Store } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CATEGORIES, toPersianDigits, type Product } from "@/lib/shop";
import { ProductCard, ProductCardSkeleton } from "./product-card";

interface ShopViewProps {
  initialQuery: string;
  initialCategory: string;
  initialType: string;
  refreshKey: number;
  onOpenProduct: (p: Product) => void;
}

export function ShopView({
  initialQuery,
  initialCategory,
  initialType,
  refreshKey,
  onOpenProduct,
}: ShopViewProps) {
  const [query, setQuery] = useState(initialQuery);
  const [debouncedQuery, setDebouncedQuery] = useState(initialQuery);
  const [category, setCategory] = useState(initialCategory || "all");
  const [type, setType] = useState(initialType || "all");
  const [sort, setSort] = useState("newest");
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // تأخیر برای جستجوی زنده
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query.trim()), 300);
    return () => clearTimeout(t);
  }, [query]);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (debouncedQuery) params.set("q", debouncedQuery);
      if (category !== "all") params.set("category", category);
      if (type !== "all") params.set("type", type);
      params.set("sort", sort);
      const res = await fetch(`/api/products?${params.toString()}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در دریافت محصولات");
      setProducts(data.products);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطای نامشخص");
    } finally {
      setLoading(false);
    }
  }, [debouncedQuery, category, type, sort]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts, refreshKey]);

  const hasFilters = debouncedQuery !== "" || category !== "all" || type !== "all" || sort !== "newest";

  const resetFilters = () => {
    setQuery("");
    setCategory("all");
    setType("all");
    setSort("newest");
  };

  const sortOptions = useMemo(
    () => [
      { value: "newest", label: "جدیدترین" },
      { value: "popular", label: "پربازدیدترین" },
      { value: "cheapest", label: "ارزان‌ترین" },
      { value: "expensive", label: "گران‌ترین" },
    ],
    []
  );

  return (
    <section className="mx-auto max-w-6xl px-4 py-10 md:py-14">
      {/* تیتر فروشگاه */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="inline-flex items-center gap-1.5 text-xs font-bold tracking-wide text-amber-600">
            <Store className="h-4 w-4" />
            قسمت فرعی: فروشگاه و محصولات
          </span>
          <h1 className="mt-1 text-2xl font-black sm:text-3xl">فروشگاه یونی‌شاپ</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            جستجو و فیلتر میان همه کتاب‌ها و جزوه‌های ثبت‌شده دانشجویان شیراز.
          </p>
        </div>
        <span className="rounded-full border bg-white px-4 py-2 text-sm font-bold text-teal-800 shadow-sm">
          {loading ? "..." : `${toPersianDigits(products.length)} محصول`}
        </span>
      </div>

      {/* فیلترها */}
      <div className="mt-6 rounded-2xl border bg-card p-4 shadow-sm">
        <div className="grid gap-3 md:grid-cols-[1fr_auto_auto_auto]">
          {/* جستجو */}
          <div className="relative">
            <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="جستجوی نام کتاب، جزوه، استاد یا درس..."
              className="h-11 pr-9"
              aria-label="جستجو در فروشگاه"
            />
          </div>

          {/* نوع */}
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="h-11 w-full md:w-36" aria-label="نوع محصول">
              <SelectValue placeholder="نوع محصول" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه موارد</SelectItem>
              <SelectItem value="BOOK">کتاب</SelectItem>
              <SelectItem value="PAMPHLET">جزوه</SelectItem>
            </SelectContent>
          </Select>

          {/* دسته‌بندی */}
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="h-11 w-full md:w-44" aria-label="دسته‌بندی">
              <SelectValue placeholder="دسته‌بندی" />
            </SelectTrigger>
            <SelectContent className="max-h-72 overflow-y-auto">
              <SelectItem value="all">همه دسته‌ها</SelectItem>
              {CATEGORIES.map((c) => (
                <SelectItem key={c.slug} value={c.slug}>
                  {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* ترتیب */}
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="h-11 w-full md:w-36" aria-label="ترتیب نمایش">
              <SelectValue placeholder="ترتیب" />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>
                  {o.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {hasFilters && (
          <div className="mt-3 flex items-center justify-between border-t pt-3">
            <p className="text-xs text-muted-foreground">
              فیلترهای فعال: {debouncedQuery && `«${debouncedQuery}»`}
              {category !== "all" && `، دسته ${category}`}
              {type !== "all" && `، ${type === "BOOK" ? "کتاب" : "جزوه"}`}
            </p>
            <Button variant="ghost" size="sm" onClick={resetFilters} className="gap-1 text-muted-foreground">
              <RotateCcw className="h-3.5 w-3.5" />
              حذف فیلترها
            </Button>
          </div>
        )}
      </div>

      {/* خطا */}
      {error && (
        <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
          <Button variant="outline" size="sm" onClick={fetchProducts} className="mr-3">
            تلاش مجدد
          </Button>
        </div>
      )}

      {/* شبکه محصولات */}
      {loading ? (
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <ProductCardSkeleton key={i} />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="mt-10 flex flex-col items-center rounded-2xl border border-dashed bg-white/50 p-12 text-center">
          <PackageSearch className="h-12 w-12 text-teal-300" />
          <h3 className="mt-4 text-lg font-bold">موردی یافت نشد</h3>
          <p className="mt-2 max-w-sm text-sm leading-7 text-muted-foreground">
            هیچ کتاب یا جزوه‌ای با این جستجو و فیلترها پیدا نشد. عبارت دیگری را امتحان کن
            یا فیلترها را حذف کن.
          </p>
          <Button variant="outline" onClick={resetFilters} className="mt-4 gap-1.5">
            <RotateCcw className="h-4 w-4" />
            حذف همه فیلترها
          </Button>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} onClick={onOpenProduct} />
          ))}
        </div>
      )}
    </section>
  );
}
