"use client";

import {
  ShieldCheck,
  HandCoins,
  MapPin,
  Clock,
  NotebookPen,
  PhoneCall,
  Store,
} from "lucide-react";

const FEATURES = [
  {
    icon: MapPin,
    title: "ویژه شیراز",
    text: "همه آگهی‌ها مربوط به دانشجویان شیراز است؛ معامله حضوری، سریع و بدون هزینه پست.",
  },
  {
    icon: HandCoins,
    title: "قیمت منصفانه",
    text: "کتاب‌ها و جزوه‌ها با قیمت دلخواه فروشنده و معمولاً خیلی ارزان‌تر از بازار عرضه می‌شوند.",
  },
  {
    icon: ShieldCheck,
    title: "بدون واسطه",
    text: "خریدار مستقیم با فروشنده در تماس است؛ هیچ کمیسیونی از معامله شما برداشته نمی‌شود.",
  },
  {
    icon: Clock,
    title: "۲۴ ساعته",
    text: "هر ساعت از شبانه‌روز می‌توانی جستجو کنی یا آگهی خودت را برای فروش ثبت کنی.",
  },
];

const STEPS = [
  {
    icon: NotebookPen,
    title: "ثبت آگهی",
    text: "کتاب یا جزوه‌ات را با قیمت و وضعیتش ثبت کن؛ کمتر از یک دقیقه طول می‌کشد.",
  },
  {
    icon: PhoneCall,
    title: "ارتباط مستقیم",
    text: "خریدار علاقه‌مند مستقیم با تو تماس می‌گیرد و جزئیات را می‌پرسد.",
  },
  {
    icon: Store,
    title: "معامله و تحویل",
    text: "حضوری در محل توافق‌شده در شیراز کتاب را تحویل بده و فروش را تکمیل کن.",
  },
];

/** بخش معرفی هدف سایت */
export function AboutSection({ onOpenSell }: { onOpenSell: () => void }) {
  return (
    <section id="about" className="scroll-mt-32 border-y bg-white/60">
      <div className="mx-auto max-w-6xl px-4 py-12 md:py-16">
        <div className="mx-auto max-w-3xl text-center">
          <span className="text-xs font-bold tracking-wide text-amber-600">هدف ما چیست؟</span>
          <h2 className="mt-2 text-2xl font-black leading-snug text-foreground sm:text-3xl">
            هیچ کتاب دانشگاهی‌ای نباید روی قفسه خاک بخورد!
          </h2>
          <p className="mt-4 text-sm leading-8 text-muted-foreground sm:text-base sm:leading-8">
            «یونی‌شاپ شیراز» با یک هدف ساده متولد شد: پیوند بین دانشجویانی که کتاب یا جزوه‌ای
            دیگر به آن نیاز ندارند، با دانشجویانی که همین امسال به آن نیاز دارند. هر ترم
            کتاب‌های گران‌قیمتی بی‌استفاده می‌مانند و بسیاری از دانشجویان دنبال نسخه‌ای
            ارزان‌تر می‌گردند؛ ما این دو گروه را بدون واسطه به هم می‌رسانیم تا هم هزینه
            تحصیل کمتر شود و هم دانش بین دانشجویان یک شهر بچرخد.
          </p>
        </div>

        {/* ویژگی‌ها */}
        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="rounded-2xl border bg-card p-5 shadow-sm transition-shadow hover:shadow-md"
            >
              <span className="inline-grid h-11 w-11 place-items-center rounded-xl bg-teal-50">
                <f.icon className="h-5 w-5 text-teal-700" />
              </span>
              <h3 className="mt-3 text-base font-bold">{f.title}</h3>
              <p className="mt-1.5 text-sm leading-7 text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>

        {/* مراحل کار */}
        <div className="mt-12">
          <h3 className="text-center text-lg font-black text-foreground">
            کار با یونی‌شاپ فقط سه قدم دارد
          </h3>
          <ol className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
            {STEPS.map((s, i) => (
              <li
                key={s.title}
                className="relative rounded-2xl border border-dashed bg-gradient-to-b from-teal-50/60 to-transparent p-5"
              >
                <span className="absolute -top-3 right-5 grid h-7 w-7 place-items-center rounded-full bg-amber-500 text-xs font-black text-white shadow">
                  {["۱", "۲", "۳"][i]}
                </span>
                <div className="flex items-center gap-2">
                  <s.icon className="h-5 w-5 text-teal-700" />
                  <h4 className="font-bold">{s.title}</h4>
                </div>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{s.text}</p>
              </li>
            ))}
          </ol>
        </div>

        {/* بنر دعوت به ثبت آگهی */}
        <div className="relative mt-12 overflow-hidden rounded-3xl bg-gradient-to-l from-teal-800 via-teal-700 to-emerald-700 p-8 text-white shadow-xl md:p-10">
          <div className="pattern-persian pointer-events-none absolute inset-0 opacity-20" aria-hidden="true" />
          <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <h3 className="text-xl font-black leading-snug sm:text-2xl">
                کتاب‌های شما هم دنبال قفسه‌ای تازه می‌گردند؟
              </h3>
              <p className="mt-2 max-w-xl text-sm leading-7 text-teal-50/90">
                همین حالا کتاب یا جزوه‌ات را برای فروش ثبت کن؛ هزاران دانشجوی شیرازی آن را
                می‌بینند. ثبت آگهی رایگان است.
              </p>
            </div>
            <button
              type="button"
              onClick={onOpenSell}
              className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-amber-500 px-6 py-3.5 text-sm font-black text-white shadow-lg shadow-amber-900/30 transition-all hover:-translate-y-0.5 hover:bg-amber-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
            >
              <NotebookPen className="h-5 w-5" />
              ثبت کتاب یا جزوه برای فروش
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
