"use client";

import { Eye, Flame, Sparkles } from "lucide-react";
import { BookCover } from "./book-cover";
import {
  CONDITION_LABEL,
  formatPrice,
  timeAgo,
  categoryDef,
  type Product,
} from "@/lib/shop";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  onClick: (product: Product) => void;
}

export function ProductCard({ product, onClick }: ProductCardProps) {
  const def = categoryDef(product.category);
  const isNew = Date.now() - new Date(product.createdAt).getTime() < 3 * 24 * 3600 * 1000;

  return (
    <article
      role="button"
      tabIndex={0}
      onClick={() => onClick(product)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick(product);
        }
      }}
      className="group cursor-pointer rounded-xl border bg-card p-3 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      aria-label={`${product.title} — ${formatPrice(product.price)} تومان`}
    >
      <div className="relative">
        <BookCover
          title={product.title}
          author={product.author}
          category={product.category}
          type={product.type}
          compact
          className="transition-shadow group-hover:shadow-xl"
        />
        {/* نشان‌ها */}
        <div className="absolute top-2 right-2 flex flex-col gap-1">
          {product.featured && (
            <Badge className="gap-1 bg-amber-500 text-white hover:bg-amber-500 shadow">
              <Flame className="h-3 w-3" />
              پرفروش
            </Badge>
          )}
          {isNew && !product.featured && (
            <Badge className="gap-1 bg-teal-600 text-white hover:bg-teal-600 shadow">
              <Sparkles className="h-3 w-3" />
              جدید
            </Badge>
          )}
        </div>
      </div>

      <div className="mt-3 space-y-1.5">
        <h3 className="line-clamp-1 text-sm font-bold text-foreground group-hover:text-primary transition-colors">
          {product.title}
        </h3>
        <p className="line-clamp-1 text-xs text-muted-foreground">{product.author}</p>

        <div className="flex flex-wrap items-center gap-1 pt-0.5">
          <Badge variant="secondary" className={cn("font-normal text-[10px]", def.text, def.soft)}>
            {def.label}
          </Badge>
          <Badge variant="outline" className="font-normal text-[10px] text-muted-foreground">
            {CONDITION_LABEL[product.condition]}
          </Badge>
        </div>

        <div className="flex items-center justify-between pt-1.5">
          <div>
            <p className="text-base font-black text-amber-600">
              {formatPrice(product.price)}
              <span className="mr-1 text-[10px] font-medium text-muted-foreground">تومان</span>
            </p>
            <p className="text-[10px] text-muted-foreground">{timeAgo(product.createdAt)}</p>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
            <Eye className="h-3 w-3" />
            {product.views}
          </div>
        </div>
      </div>
    </article>
  );
}

export function ProductCardSkeleton() {
  return (
    <div className="rounded-xl border bg-card p-3 shadow-sm">
      <div className="aspect-[3/4] w-full animate-pulse rounded-lg bg-muted" />
      <div className="mt-3 space-y-2">
        <div className="h-4 w-3/4 animate-pulse rounded bg-muted" />
        <div className="h-3 w-1/2 animate-pulse rounded bg-muted" />
        <div className="h-6 w-2/3 animate-pulse rounded bg-muted" />
      </div>
    </div>
  );
}
