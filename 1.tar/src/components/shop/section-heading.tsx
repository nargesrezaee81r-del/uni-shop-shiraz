"use client";

import { ArrowLeft } from "lucide-react";

interface SectionHeadingProps {
  kicker: string;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

/** تیتر بخش با برچسب کوچک، عنوان و دکمه «مشاهده همه» */
export function SectionHeading({
  kicker,
  title,
  description,
  actionLabel,
  onAction,
}: SectionHeadingProps) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div>
        <span className="text-xs font-bold tracking-wide text-amber-600">{kicker}</span>
        <h2 className="mt-1 text-2xl font-black text-foreground sm:text-3xl">{title}</h2>
        {description && (
          <p className="mt-2 max-w-xl text-sm leading-7 text-muted-foreground">{description}</p>
        )}
      </div>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="group inline-flex items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50/60 px-4 py-2 text-sm font-bold text-teal-800 transition-colors hover:bg-teal-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {actionLabel}
          <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-0.5" />
        </button>
      )}
    </div>
  );
}
