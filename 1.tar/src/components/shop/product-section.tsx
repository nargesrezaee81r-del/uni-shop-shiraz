"use client";

import type { Product } from "@/lib/shop";
import { ProductCard } from "./product-card";
import { SectionHeading } from "./section-heading";

interface ProductSectionProps {
  id?: string;
  kicker: string;
  title: string;
  description: string;
  products: Product[];
  onViewAll: () => void;
  onOpenProduct: (p: Product) => void;
  emptyText?: string;
}

/** بخش نمایش محصولات (جدیدترین‌ها یا پرفروش‌ها) در صفحه خانه */
export function ProductSection({
  id,
  kicker,
  title,
  description,
  products,
  onViewAll,
  onOpenProduct,
  emptyText = "فعلاً آگهی‌ای در این بخش ثبت نشده است.",
}: ProductSectionProps) {
  return (
    <section id={id} className="mx-auto max-w-6xl scroll-mt-32 px-4 py-10 md:py-12">
      <SectionHeading
        kicker={kicker}
        title={title}
        description={description}
        actionLabel="مشاهده همه"
        onAction={onViewAll}
      />

      {products.length === 0 ? (
        <p className="mt-8 rounded-2xl border border-dashed bg-white/50 p-8 text-center text-sm text-muted-foreground">
          {emptyText}
        </p>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} onClick={onOpenProduct} />
          ))}
        </div>
      )}
    </section>
  );
}
