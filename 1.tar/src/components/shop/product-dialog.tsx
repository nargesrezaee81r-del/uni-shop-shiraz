"use client";

import { useState } from "react";
import {
  BookOpen,
  ScrollText,
  Landmark,
  Tag,
  BadgeCheck,
  Eye,
  Clock,
  Phone,
  User,
  Copy,
  Check,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { BookCover } from "./book-cover";
import {
  CONDITION_LABEL,
  TYPE_LABEL,
  categoryDef,
  formatPrice,
  timeAgo,
  type Product,
} from "@/lib/shop";

interface ProductDialogProps {
  product: Product | null;
  onClose: () => void;
}

/** دیالوگ جزئیات محصول + تماس با فروشنده */
export function ProductDialog({ product, onClose }: ProductDialogProps) {
  const [showPhone, setShowPhone] = useState(false);
  const [copied, setCopied] = useState(false);

  // ریست وضعیت هنگام باز شدن محصول جدید
  const key = product?.id ?? "none";

  return (
    <Dialog
      key={key}
      open={!!product}
      onOpenChange={(open) => {
        if (!open) {
          setShowPhone(false);
          setCopied(false);
          onClose();
        }
      }}
    >
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="text-right text-xl font-black leading-relaxed">
            {product?.title}
          </DialogTitle>
          <DialogDescription className="text-right">
            جزئیات کامل آگهی و راه ارتباطی با فروشنده
          </DialogDescription>
        </DialogHeader>

        {product && (
          <div className="grid gap-6 sm:grid-cols-[220px_1fr]">
            {/* جلد */}
            <div>
              <BookCover
                title={product.title}
                author={product.author}
                category={product.category}
                type={product.type}
              />
              <p className="mt-3 flex items-center justify-center gap-1 text-xs text-muted-foreground">
                <Eye className="h-3.5 w-3.5" />
                {product.views} بازدید
              </p>
            </div>

            {/* اطلاعات */}
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <Badge
                  className={
                    product.type === "BOOK"
                      ? "gap-1 bg-teal-700 hover:bg-teal-700"
                      : "gap-1 bg-emerald-600 hover:bg-emerald-600"
                  }
                >
                  {product.type === "BOOK" ? (
                    <BookOpen className="h-3 w-3" />
                  ) : (
                    <ScrollText className="h-3 w-3" />
                  )}
                  {TYPE_LABEL[product.type]}
                </Badge>
                <Badge variant="secondary" className={categoryDef(product.category).text}>
                  <Tag className="h-3 w-3" />
                  {product.category}
                </Badge>
                <Badge variant="outline" className="gap-1 text-amber-600 border-amber-300">
                  <BadgeCheck className="h-3 w-3" />
                  {CONDITION_LABEL[product.condition]}
                </Badge>
                {product.featured && (
                  <Badge className="bg-amber-500 hover:bg-amber-500">پرفروش / پیشنهادی</Badge>
                )}
              </div>

              <p className="rounded-xl bg-amber-50 border border-amber-200 px-4 py-3 text-2xl font-black text-amber-700">
                {formatPrice(product.price)}
                <span className="mr-1.5 text-xs font-medium text-amber-600/80">تومان</span>
              </p>

              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <User className="h-4 w-4 text-teal-600" />
                  نویسنده / استاد: <span className="font-bold text-foreground">{product.author}</span>
                </li>
                {product.course && (
                  <li className="flex items-center gap-2">
                    <ScrollText className="h-4 w-4 text-teal-600" />
                    درس: <span className="font-bold text-foreground">{product.course}</span>
                  </li>
                )}
                {product.university && (
                  <li className="flex items-center gap-2">
                    <Landmark className="h-4 w-4 text-teal-600" />
                    دانشگاه: <span className="font-bold text-foreground">{product.university}</span>
                  </li>
                )}
                <li className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-teal-600" />
                  زمان ثبت: {timeAgo(product.createdAt)}
                </li>
              </ul>

              {product.description && (
                <>
                  <Separator />
                  <div>
                    <h4 className="mb-1.5 text-sm font-bold">توضیحات فروشنده</h4>
                    <p className="text-sm leading-7 text-muted-foreground">{product.description}</p>
                  </div>
                </>
              )}

              <Separator />

              {/* فروشنده */}
              <div className="rounded-xl border bg-teal-50/50 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs text-muted-foreground">فروشنده</p>
                    <p className="font-bold">{product.sellerName}</p>
                  </div>
                  {!showPhone ? (
                    <Button
                      onClick={() => setShowPhone(true)}
                      className="gap-1.5 bg-teal-700 hover:bg-teal-800"
                    >
                      <Phone className="h-4 w-4" />
                      نمایش شماره تماس
                    </Button>
                  ) : (
                    <div className="flex items-center gap-2">
                      <a
                        href={`tel:${product.phone}`}
                        dir="ltr"
                        className="rounded-lg bg-white px-3 py-2 font-black tracking-wider text-teal-800 shadow-sm"
                      >
                        {product.phone}
                      </a>
                      <Button
                        variant="outline"
                        size="icon"
                        aria-label="کپی شماره"
                        onClick={() => {
                          navigator.clipboard?.writeText(product.phone).then(() => {
                            setCopied(true);
                            setTimeout(() => setCopied(false), 1500);
                          });
                        }}
                      >
                        {copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  )}
                </div>
                <p className="mt-3 text-[11px] leading-5 text-muted-foreground">
                  معامله را حضوری و در محل امن انجام دهید؛ یونی‌شاپ فقط واسطه آگهی است.
                </p>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
