"use client";

import { useState } from "react";
import {
  BookOpen,
  ScrollText,
  Loader2,
  CircleCheck,
  NotebookPen,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CATEGORIES } from "@/lib/shop";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface SellDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

interface FormState {
  type: "BOOK" | "PAMPHLET";
  title: string;
  author: string;
  category: string;
  course: string;
  university: string;
  price: string;
  condition: "NEW" | "LIKE_NEW" | "USED";
  description: string;
  sellerName: string;
  phone: string;
}

const initialForm: FormState = {
  type: "BOOK",
  title: "",
  author: "",
  category: "",
  course: "",
  university: "",
  price: "",
  condition: "USED",
  description: "",
  sellerName: "",
  phone: "",
};

/** دیالوگ ثبت کتاب یا جزوه برای فروش */
export function SellDialog({ open, onOpenChange, onSuccess }: SellDialogProps) {
  const [form, setForm] = useState<FormState>(initialForm);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const { toast } = useToast();

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, price: Number(form.price) }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "ثبت آگهی ناموفق بود.");
      }
      setSuccess(true);
      toast({
        title: "آگهی شما ثبت شد",
        description: "«" + form.title + "» اکنون در فروشگاه یونی‌شاپ نمایش داده می‌شود.",
      });
      setTimeout(() => {
        setSuccess(false);
        setForm(initialForm);
        onOpenChange(false);
        onSuccess();
      }, 1600);
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای نامشخص");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!submitting) onOpenChange(o); }}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-right text-xl font-black">
            <NotebookPen className="h-5 w-5 text-amber-500" />
            ثبت کتاب یا جزوه برای فروش
          </DialogTitle>
          <DialogDescription className="text-right">
            فرم زیر را پر کن؛ آگهی تو بعد از ثبت فوراً در فروشگاه نمایش داده می‌شود.
          </DialogDescription>
        </DialogHeader>

        {success ? (
          <div className="flex flex-col items-center py-10 text-center">
            <CircleCheck className="h-14 w-14 text-emerald-500" />
            <h3 className="mt-4 text-lg font-black text-emerald-700">آگهی با موفقیت ثبت شد!</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              در حال انتقال به فروشگاه...
            </p>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-5">
            {/* نوع آگهی */}
            <RadioGroup
              value={form.type}
              onValueChange={(v) => set("type", v as "BOOK" | "PAMPHLET")}
              className="grid grid-cols-2 gap-3"
            >
              {(
                [
                  { value: "BOOK", label: "کتاب", icon: BookOpen },
                  { value: "PAMPHLET", label: "جزوه", icon: ScrollText },
                ] as const
              ).map((opt) => (
                <Label
                  key={opt.value}
                  htmlFor={`type-${opt.value}`}
                  className={cn(
                    "flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 p-4 text-sm font-bold transition-all hover:bg-teal-50/60",
                    form.type === opt.value
                      ? "border-teal-600 bg-teal-50 text-teal-800"
                      : "border-border text-muted-foreground"
                  )}
                >
                  <RadioGroupItem id={`type-${opt.value}`} value={opt.value} className="sr-only" />
                  <opt.icon className="h-5 w-5" />
                  {opt.label}
                </Label>
              ))}
            </RadioGroup>

            {/* عنوان و نویسنده */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="sell-title">عنوان *</Label>
                <Input
                  id="sell-title"
                  value={form.title}
                  onChange={(e) => set("title", e.target.value)}
                  placeholder="مثلاً: ریاضی عمومی ۱"
                  required
                  minLength={3}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sell-author">
                  {form.type === "BOOK" ? "نویسنده *" : "استاد *"}
                </Label>
                <Input
                  id="sell-author"
                  value={form.author}
                  onChange={(e) => set("author", e.target.value)}
                  placeholder={form.type === "BOOK" ? "مثلاً: نیک‌زاد" : "مثلاً: دکتر احمدی"}
                  required
                  minLength={2}
                />
              </div>
            </div>

            {/* دسته و وضعیت */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>دسته‌بندی *</Label>
                <Select value={form.category} onValueChange={(v) => set("category", v)}>
                  <SelectTrigger aria-label="انتخاب دسته‌بندی">
                    <SelectValue placeholder="انتخاب دسته..." />
                  </SelectTrigger>
                  <SelectContent className="max-h-64 overflow-y-auto">
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c.slug} value={c.slug}>
                        {c.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>وضعیت *</Label>
                <Select
                  value={form.condition}
                  onValueChange={(v) => set("condition", v as FormState["condition"])}
                >
                  <SelectTrigger aria-label="انتخاب وضعیت">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="NEW">نو</SelectItem>
                    <SelectItem value="LIKE_NEW">در حد نو</SelectItem>
                    <SelectItem value="USED">کارکرده</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* درس و دانشگاه — فقط برای جزوه‌ها نمایش درس اجباری‌تر است */}
            <div className="grid gap-4 sm:grid-cols-2">
              {form.type === "PAMPHLET" && (
                <div className="space-y-1.5">
                  <Label htmlFor="sell-course">نام درس</Label>
                  <Input
                    id="sell-course"
                    value={form.course}
                    onChange={(e) => set("course", e.target.value)}
                    placeholder="مثلاً: مکانیک سیالات"
                  />
                </div>
              )}
              <div className="space-y-1.5">
                <Label htmlFor="sell-uni">دانشگاه (اختیاری)</Label>
                <Input
                  id="sell-uni"
                  value={form.university}
                  onChange={(e) => set("university", e.target.value)}
                  placeholder="مثلاً: دانشگاه شیراز"
                />
              </div>
            </div>

            {/* قیمت */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="sell-price">قیمت (تومان) *</Label>
                <Input
                  id="sell-price"
                  type="number"
                  min={0}
                  step={1000}
                  value={form.price}
                  onChange={(e) => set("price", e.target.value)}
                  placeholder="مثلاً 150000"
                  dir="ltr"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sell-seller">نام شما (فروشنده) *</Label>
                <Input
                  id="sell-seller"
                  value={form.sellerName}
                  onChange={(e) => set("sellerName", e.target.value)}
                  placeholder="نام و نام خانوادگی"
                  required
                  minLength={2}
                />
              </div>
            </div>

            {/* موبایل */}
            <div className="space-y-1.5">
              <Label htmlFor="sell-phone">شماره موبایل * </Label>
              <Input
                id="sell-phone"
                type="tel"
                value={form.phone}
                onChange={(e) => set("phone", e.target.value)}
                placeholder="0917xxxxxxx"
                dir="ltr"
                className="text-left"
                required
                pattern="09[0-9]{9}"
              />
              <p className="text-[11px] text-muted-foreground">
                شماره تو فقط بعد از کلیک «نمایش شماره تماس» توسط خریدار دیده می‌شود.
              </p>
            </div>

            {/* توضیحات */}
            <div className="space-y-1.5">
              <Label htmlFor="sell-desc">توضیحات (اختیاری)</Label>
              <Textarea
                id="sell-desc"
                value={form.description}
                onChange={(e) => set("description", e.target.value)}
                placeholder="وضعیت جلد و صفحات، سال چاپ، نشر و هر نکته‌ای که خریدار باید بداند..."
                rows={3}
              />
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <Button
                type="button"
                variant="outline"
                disabled={submitting}
                onClick={() => onOpenChange(false)}
              >
                انصراف
              </Button>
              <Button
                type="submit"
                disabled={submitting}
                className="bg-amber-500 text-white hover:bg-amber-600"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    در حال ثبت...
                  </>
                ) : (
                  <>
                    <CircleCheck className="h-4 w-4" />
                    ثبت آگهی در فروشگاه
                  </>
                )}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
