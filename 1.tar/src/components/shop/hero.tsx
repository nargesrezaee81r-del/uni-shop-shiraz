"use client";

import { useState } from "react";
import { Search, BookOpen, ScrollText, Plus, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BookCover } from "./book-cover";
import { toPersianDigits, type Product } from "@/lib/shop";

interface HeroProps {
  onSearch: (query: string, type: string) => void;
  onOpenSell: () => void;
  onGoShop: () => void;
  totalProducts: number;
  sampleProducts: Product[];
}

export function Hero({ onSearch, onOpenSell, onGoShop, totalProducts, sampleProducts }: HeroProps) {
  const [query, setQuery] = useState("");
  const [type, setType] = useState("all");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query.trim(), type);
  };

  const stats = [
    { value: toPersianDigits(totalProducts), label: "آگهی فعال" },
    { value: toPersianDigits(8), label: "دسته‌بندی" },
    { value: toPersianDigits(3), label: "دانشگاه شیراز" },
    { value: "۱۰۰٪", label: "معامله مستقیم" },
  ];

  return (
    <section className="relative overflow-hidden border-b bg-gradient-to-b from-teal-50/80 via-background to-background">
      {/* پس‌زمینه الگوی ایرانی */}
      <div className="pattern-persian pointer-events-none absolute inset-0 opacity-60" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-teal-200/40 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -bottom-24 -right-16 h-72 w-72 rounded-full bg-amber-200/40 blur-3xl"
        aria-hidden="true"
      />

      <div className="relative mx-auto grid max-w-6xl gap-10 px-4 pb-14 pt-12 md:grid-cols-2 md:items-center md:pb-20 md:pt-16">
        {/* متن و جستجو */}
        <div>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-teal-200 bg-white/70 px-3 py-1 text-xs font-medium text-teal-800 shadow-sm">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
            مخصوص دانشجویان شیراز
          </span>

          <h1 className="mt-4 text-3xl font-black leading-[1.35] text-foreground sm:text-4xl sm:leading-[1.35]">
            کتاب و جزوه دانشگاهی‌ات را
            <span className="mx-2 bg-gradient-to-l from-teal-700 to-emerald-600 bg-clip-text text-transparent">
              بخر، بفروش
            </span>
            !
          </h1>

          <p className="mt-4 max-w-md text-sm leading-7 text-muted-foreground sm:text-base sm:leading-8">
            «یونی‌شاپ شیراز» بازار آنلاین کتاب‌های درسی، جزوه‌های اساتید و منابع کنکور و ارشد
            است. جستجو کن، مستقیم با صاحب کتاب تماس بگیر و با قیمتی منصفانه معامله کن.
          </p>

          {/* کادر جستجو */}
          <form
            onSubmit={submit}
            className="mt-6 flex max-w-lg flex-col gap-2 rounded-2xl border bg-white/80 p-2 shadow-lg shadow-teal-900/5 backdrop-blur sm:flex-row"
            role="search"
            aria-label="جستجوی کتاب و جزوه"
          >
            <Select value={type} onValueChange={setType}>
              <SelectTrigger className="w-full shrink-0 border-0 bg-muted/60 sm:w-28" aria-label="نوع جستجو">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه</SelectItem>
                <SelectItem value="BOOK">
                  <span className="flex items-center gap-1.5">
                    <BookOpen className="h-3.5 w-3.5" /> کتاب
                  </span>
                </SelectItem>
                <SelectItem value="PAMPHLET">
                  <span className="flex items-center gap-1.5">
                    <ScrollText className="h-3.5 w-3.5" /> جزوه
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>

            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="نام کتاب، جزوه، استاد یا درس..."
              className="h-11 flex-1 border-0 bg-transparent text-sm shadow-none focus-visible:ring-0"
              aria-label="عبارت جستجو"
            />

            <Button type="submit" className="h-11 gap-2 bg-teal-700 px-6 hover:bg-teal-800">
              <Search className="h-4 w-4" />
              جستجو
            </Button>
          </form>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            <Button
              variant="outline"
              onClick={onGoShop}
              className="gap-1.5 border-teal-700 text-teal-800 hover:bg-teal-50"
            >
              ورود به فروشگاه
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <Button
              onClick={onOpenSell}
              className="gap-1.5 bg-amber-500 text-white hover:bg-amber-600"
            >
              <Plus className="h-4 w-4" />
              ثبت کتاب یا جزوه برای فروش
            </Button>
          </div>

          {/* آمار */}
          <dl className="mt-8 grid max-w-md grid-cols-4 gap-3">
            {stats.map((s) => (
              <div key={s.label} className="rounded-xl border bg-white/60 px-2 py-3 text-center shadow-sm">
                <dt className="order-2 mt-1 text-[10px] leading-4 text-muted-foreground">{s.label}</dt>
                <dd className="text-lg font-black text-teal-800">{s.value}</dd>
              </div>
            ))}
          </dl>
        </div>

        {/* تصویر: جلدهای شناور */}
        <div className="relative hidden h-[420px] md:block" aria-hidden="true">
          {sampleProducts[0] && (
            <div
              className="animate-float-soft absolute right-4 top-6 w-48 shadow-xl"
              style={{ ["--float-rotate" as string]: "6deg" }}
            >
              <BookCover
                title={sampleProducts[0].title}
                author={sampleProducts[0].author}
                category={sampleProducts[0].category}
                type={sampleProducts[0].type}
              />
            </div>
          )}
          {sampleProducts[1] && (
            <div
              className="animate-float-soft absolute left-6 top-24 w-44 shadow-xl"
              style={{ ["--float-rotate" as string]: "-8deg", animationDelay: "1.2s" }}
            >
              <BookCover
                title={sampleProducts[1].title}
                author={sampleProducts[1].author}
                category={sampleProducts[1].category}
                type={sampleProducts[1].type}
              />
            </div>
          )}
          {sampleProducts[2] && (
            <div
              className="animate-float-soft absolute bottom-2 right-32 w-40 shadow-xl"
              style={{ ["--float-rotate" as string]: "-2deg", animationDelay: "2.4s" }}
            >
              <BookCover
                title={sampleProducts[2].title}
                author={sampleProducts[2].author}
                category={sampleProducts[2].category}
                type={sampleProducts[2].type}
              />
            </div>
          )}

          {/* کارت قیمت */}
          <div className="absolute bottom-10 left-0 rounded-2xl border bg-white/90 px-4 py-3 shadow-lg backdrop-blur">
            <p className="text-[10px] text-muted-foreground">از ۲۵٫۰۰۰ تومان</p>
            <p className="text-sm font-black text-teal-800">شروع قیمت جزوه‌ها</p>
          </div>
        </div>
      </div>
    </section>
  );
}
