import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const vazirmatn = localFont({
  src: [
    {
      path: "../../public/fonts/Vazirmatn-Regular.woff2",
      weight: "400",
      style: "normal",
    },
    {
      path: "../../public/fonts/Vazirmatn-Medium.woff2",
      weight: "500",
      style: "normal",
    },
    {
      path: "../../public/fonts/Vazirmatn-Bold.woff2",
      weight: "700",
      style: "normal",
    },
    {
      path: "../../public/fonts/Vazirmatn-Black.woff2",
      weight: "900",
      style: "normal",
    },
  ],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Uni Shop Shiraz | یونی‌شاپ شیراز — بازار کتاب و جزوه دانشگاهی",
  description:
    "یونی‌شاپ شیراز؛ مرجع خرید و فروش کتاب و جزوه دانشگاهی بین دانشجویان شیراز. کتاب‌های درسی، جزوه‌های اساتید و منابع کنکور ارشد را خرید و فروش کنید.",
  keywords: [
    "یونی شاپ شیراز",
    "خرید کتاب دست دوم",
    "فروش جزوه دانشگاهی",
    "کتاب دانشگاهی شیراز",
    "Uni Shop Shiraz",
  ],
  authors: [{ name: "Uni Shop Shiraz" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body
        className={`${vazirmatn.variable} antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
