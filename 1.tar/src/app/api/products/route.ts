import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/products — لیست محصولات با جستجو و فیلتر
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = (searchParams.get("q") || "").trim();
    const category = searchParams.get("category") || "";
    const type = searchParams.get("type") || "";
    const sort = searchParams.get("sort") || "newest";

    const where: Record<string, unknown> = { status: "AVAILABLE" };

    if (q) {
      where.OR = [
        { title: { contains: q } },
        { author: { contains: q } },
        { category: { contains: q } },
        { course: { contains: q } },
        { university: { contains: q } },
        { description: { contains: q } },
      ];
    }
    if (category) where.category = category;
    if (type) where.type = type;

    let orderBy: Record<string, "asc" | "desc"> = { createdAt: "desc" };
    if (sort === "cheapest") orderBy = { price: "asc" };
    else if (sort === "expensive") orderBy = { price: "desc" };
    else if (sort === "popular") orderBy = { views: "desc" };

    const products = await db.product.findMany({ where, orderBy });
    return NextResponse.json({ products });
  } catch (error) {
    console.error("GET /api/products error:", error);
    return NextResponse.json(
      { error: "خطا در دریافت محصولات" },
      { status: 500 }
    );
  }
}

// POST /api/products — ثبت آگهی فروش کتاب یا جزوه
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      title,
      author,
      type,
      category,
      course,
      university,
      price,
      condition,
      description,
      sellerName,
      phone,
    } = body || {};

    // اعتبارسنجی ورودی‌ها
    const errors: string[] = [];
    if (!title || typeof title !== "string" || title.trim().length < 3)
      errors.push("عنوان باید حداقل ۳ حرف باشد.");
    if (!author || typeof author !== "string" || author.trim().length < 2)
      errors.push("نام نویسنده یا استاد الزامی است.");
    if (type !== "BOOK" && type !== "PAMPHLET")
      errors.push("نوع آگهی نامعتبر است.");
    if (!category || typeof category !== "string")
      errors.push("انتخاب دسته‌بندی الزامی است.");
    const priceNum = Number(price);
    if (!Number.isFinite(priceNum) || priceNum < 0 || priceNum > 100_000_000)
      errors.push("قیمت نامعتبر است.");
    if (!condition || !["NEW", "LIKE_NEW", "USED"].includes(condition))
      errors.push("وضعیت کالا نامعتبر است.");
    if (!sellerName || typeof sellerName !== "string" || sellerName.trim().length < 2)
      errors.push("نام فروشنده الزامی است.");
    if (!phone || !/^09\d{9}$/.test(String(phone).replace(/\D/g, "")))
      errors.push("شماره موبایل باید با ۰۹ شروع شده و ۱۱ رقم باشد.");

    if (errors.length > 0) {
      return NextResponse.json({ error: errors.join(" ") }, { status: 400 });
    }

    const product = await db.product.create({
      data: {
        title: String(title).trim(),
        author: String(author).trim(),
        type,
        category,
        course: course ? String(course).trim() : null,
        university: university ? String(university).trim() : null,
        price: Math.round(priceNum),
        condition,
        description: description ? String(description).trim() : null,
        sellerName: String(sellerName).trim(),
        phone: String(phone).replace(/\D/g, ""),
      },
    });

    return NextResponse.json({ product }, { status: 201 });
  } catch (error) {
    console.error("POST /api/products error:", error);
    return NextResponse.json(
      { error: "خطا در ثبت آگهی. لطفاً دوباره تلاش کنید." },
      { status: 500 }
    );
  }
}
